<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="directionalsigns__crgoingroundandround_zps92f46352" tilewidth="16" tileheight="16" tilecount="48" columns="6">
 <image source="directionalsigns__crgoingroundandround_zps92f46352.png" width="96" height="128"/>
</tileset>
